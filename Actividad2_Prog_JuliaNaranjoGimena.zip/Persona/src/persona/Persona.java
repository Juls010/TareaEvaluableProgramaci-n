package persona;

public class Persona {
	//Variables del ejercicio 1:
	private String nombre;
	private String apellidos;
	private String dni;
	private int  AnyoDeNacimiento;
	//Incluyo los dos nuevos atributos del ejercicio 2:
	private String paisNacimiento;
	private char genero;
	
	//Constructor con los atributos del ejercicio 1, que seria hasta el AnyoDeNacimiento.
	//Incluyo al constructor los atributos "nacionalidad" y "genero" de la persona.
	public Persona(String nombre,String apellidos, String dni, int AnyoDeNacimiento, String paisNacimiento, char genero) {
		this.nombre=nombre;
		this.apellidos=apellidos;
		this.dni=dni;
		this.AnyoDeNacimiento=AnyoDeNacimiento;
		this.paisNacimiento=paisNacimiento;
		this.genero=genero;
	}
	
	//Metodo toString que sirve para devolver una cadena, a la que le he anadido los atributos de la persona:
	public String toString(){
		return "Persona: "+"\n"+
				"Nombre: "+nombre+"\n"+
				"Apellidos: "+apellidos+"\n"+
				"dni: "+dni+"\n"+
				"AnyoDeNacimiento: "+ AnyoDeNacimiento+"\n"+
				"Pais de Nacimiento: "+ paisNacimiento+"\n"+
				"Genero: "+genero;
		
	}
	
	public void genero() {
		//He creado un metodo para consultar el genero de la persona
		if(genero =='H') {
			System.out.println("El genero de la persona es Hombre"+"\n"); //Si el valor de genero es igual a H, la persona es hombre
		}else if(genero=='M') {
			System.out.println("El genero de la persona es Mujer"+"\n"); //Si el valor de genero es igual a M, la persona es mujer
		}else {
			System.out.println("El genero introducido no es valido."+"\n"); //En el caso de introducir otro valor, no es valido
		}
	}

	public  static void main(String []args) {
		//Metodo main, donde creo a "persona1" y "persona2"
		//Anado a "persona1" y "persona2" los nuevos atributos de "paisNacimiento" y "genero"
		Persona persona1 = new Persona ("Miguel Angel","Conde Diaz","38678765Q",1976,"Espana",'H');
		Persona persona2 = new Persona ("Daniel","Diaz Perez","28898765M",1990,"Francia",'H');
		//Saco por pantalla los datos de cada persona usando el metodo toString() y ademas llamo al metodo genero() para consultar su genero de cada persona
		System.out.println(persona1.toString());
		persona1.genero();
		System.out.println(persona2.toString());
		persona2.genero();
		
	}
	
	
	
	
	
	
	
	
}

